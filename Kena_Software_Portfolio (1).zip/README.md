# Kena Edjeta Software Portfolio

## Overview
This portfolio contains Java and GUI applications demonstrating:

- Object-Oriented Programming
- GUI Development
- Algorithms and Recursion
- Exception Handling
- Data Structures

## Best Projects for Hiring Managers
1. Payroll System
2. Expression Evaluator GUI
3. Loan Calculator GUI
4. Bank Account System
5. Recursive Algorithms

## Author
Kena Edjeta
Software Developer
