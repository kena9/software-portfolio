# Student Certificate Manager

## Overview
Manages students and certificates using ArrayList and HashMap.

## Technologies
- Java
- ArrayList
- HashMap

## Features
- Store students
- Search by certificate
- Efficient lookup

## Why this project matters
Demonstrates real-world data structure usage.
