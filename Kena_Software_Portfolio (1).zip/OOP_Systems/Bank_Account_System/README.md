# Bank Account System (Java)

## Overview
Simulates banking operations with inheritance.

## Technologies
- Java
- OOP

## Features
- Deposit and withdraw
- Monthly processing
- Savings account inheritance

## Why this project matters
Demonstrates OOP principles including inheritance and encapsulation.
