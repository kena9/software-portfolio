# Payroll System (Java)

## Overview
Enterprise-style payroll system with exception handling.

## Technologies
- Java
- Object-Oriented Programming

## Features
- Employee payroll calculation
- Custom exceptions
- Input validation

## Why this project matters
Demonstrates enterprise-level architecture and exception handling.
