# Loan Calculator (JavaFX)

## Overview
A financial calculator GUI that computes monthly and total payments.

## Technologies
- Java
- JavaFX

## Features
- Monthly payment calculation
- Total payment calculation
- User-friendly interface

## Why this project matters
Shows real-world financial application development.
