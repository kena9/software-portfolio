# Expression Evaluator (JavaFX)

## Overview
A GUI-based calculator that evaluates mathematical expressions using a custom parsing algorithm.

## Technologies
- Java
- JavaFX
- Scene Builder
- MVC Architecture

## Features
- Evaluate expressions like: 5*20078
- GUI interface with input field and result display
- Error handling

## Why this project matters
Demonstrates GUI development, algorithm implementation, and MVC design.
